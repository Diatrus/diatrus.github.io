export CVS_RSH=ssh
