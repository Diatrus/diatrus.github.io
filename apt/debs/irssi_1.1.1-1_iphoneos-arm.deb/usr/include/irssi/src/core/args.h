#ifndef __ARGS_H
#define __ARGS_H

void args_register(GOptionEntry *options);
void args_execute(int argc, char *argv[]);

#endif
