#ifndef __FE_CHANNELS_H
#define __FE_CHANNELS_H

void fe_settings_set_print(const char *key);

#endif
