#ifndef __FE_DCC_H
#define __FE_DCC_H

char *dcc_get_size_str(uoff_t size);
void dcc_list_print_file(FILE_DCC_REC *dcc);

#endif
