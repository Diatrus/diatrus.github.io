# frozen_string_literal: true
module Psych
  class Set < ::Hash
  end
end
