alias less='less -R'
export PAGER='less'
